https://github.com/SanderMertens/ecs-faq?tab=readme-ov-file#what-is-ecs

this is literally the greatest link known to man