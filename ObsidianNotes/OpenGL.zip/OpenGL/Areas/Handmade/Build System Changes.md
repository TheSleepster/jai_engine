## Goals
- Move from CMake to a `build.bat` based system where compilation will be more simple and dynamic.
- Allow use with Visual Studio 2022 for it's debugger
- Allow the use of a "hot-reloading" system using the build.bat