- [x] Decide which language would be best applicable
- [x] Find the packages needed

## The Language will be Rust

- [ ] Get Tokio and Serenity working