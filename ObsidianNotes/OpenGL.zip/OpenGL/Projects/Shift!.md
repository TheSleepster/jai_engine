## TODO:

Zelda-like dungeon crawler. Adds the ability to shift between dimensions. 

- [ ] Add a General 2D animation system. Applies to all entities. AI, Player, and map components.
- [ ] Add a method for creating the map. Preferably a 2D array of integer components that relate to tileset and entity spawning positions.
































`
void 
animateSprite(Entity *entity) 
{
  switch(entity->animationState) 
  {
    case IDLE: 
      {
        entity->srcRect = 
        {
          (real32)((entity->sprite.width/entity->sheetLength) * entity->currentAnimationFrame), 
          0, (real32)entity->sprite.width/entity->sheetLength, (real32)entity->sprite.height
        };
        entity->currentFrameTimer++;
        if(entity->currentFrameTimer >= entity->frameDelay) 
        {
          entity->currentAnimationFrame++;
          entity->currentFrameTimer = 0;
        }

        if(entity->currentAnimationFrame >= entity->idleFrameCount) 
        {
          entity->currentAnimationFrame = 0;
        }
      }break;
    case WALKING: 
      {
        entity->srcRect = 
        {
          (real32)((entity->sprite.width/entity->sheetLength) * entity->currentAnimationFrame), 
          0, (real32)entity->sprite.width/entity->sheetLength, (real32)entity->sprite.height
        };
        entity->currentFrameTimer++;
        if(entity->currentFrameTimer >= entity->frameDelay) 
        {
          entity->currentAnimationFrame++;
          entity->currentFrameTimer = 0;
        }

        if(entity->currentAnimationFrame >= entity->walkingFrameCount) 
        {
          entity->currentAnimationFrame = 4;
        }
      }break;
    default: 
      { 
        printf("There is no animation to be played!\n");
      }break;
  }
}`